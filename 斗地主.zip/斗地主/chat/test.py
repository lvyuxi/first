#!/usr/bin/python3.5
#    -*- coding:utf-8 -*-  
#    @Filename      :  test.py
#    @Author        :  搏鲨
#    @Create date   :  18-9-12 下午11:18
#    @Email         :  1170120381@qq.com
#    @QQ            :  1170120381
#    @Blog          :  http://www.cnblogs.com/bosha/
#    @license       :  (C) Copyright 2018-2020,  搏鲨所有.
"""
 
"""
from tkinter import *

top = Tk()
top.geometry('300x300')
l = Label(text='123')
l.place(x=100, y=100)
mainloop()